from kyt import *


@bot.on(events.CallbackQuery(data=b'add-ip'))
async def add_ip(event):
	async def add_ip_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**NEW IP:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**NAMA:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**EXPIRED (HARI):**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		cmd = f'printf "%s\n" "1" "{user}" "sleep 3" "{exp}" "{pw}" | m-ip | sleep 10 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.edit(f"""
**» SUCCES CREATE**
**» DONE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await add_ip_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'change-ip'))
async def change_ip(event):
	async def change_ip_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**IP OLD:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**IP NEW:**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" "2" "{user}" "sleep 3" "{exp}" | m-ip | sleep 10 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.edit(f"""
**» SUCCES CREATE**
**» DONE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await change_ip_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'renew-ip'))
async def renew_ip(event):
	async def renew_ip_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**IP USER:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**EXPIRED (HARI):**")
			exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			exp = (await exp).raw_text
		cmd = f'printf "%s\n" "3" "{user}" "sleep 3" "{exp}" | m-ip | sleep 10 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.edit(f"""
**» SUCCES CREATE**
**» DONE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await renew_ip_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'delete-ip'))
async def change_ip(event):
	async def change_ip_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**IP OLD:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" "4" "{user}" | m-ip | sleep 10 | exit'
		subprocess.check_output(cmd, shell=True)
		await event.edit(f"""
**» SUCCES CREATE**
**» DONE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await change_ip_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)


@bot.on(events.NewMessage(pattern=r"(?:.admin|/admin)$"))
@bot.on(events.CallbackQuery(data=b'admin'))
async def start(event):
	inline = [
[Button.inline("ADD IP","add-ip"),
Button.inline("CHANGE IP","change-ip")],
[Button.inline("RENEW IP","renew-ip"),
Button.inline("DELETE IP","delete-ip")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ipvps = f" curl -s ipv4.icanhazip.com"
		ipsaya = subprocess.check_output(ipvps, shell=True).decode("ascii")
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")

		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**  ☘️ BOT REGIS WokszXD ☘️**
━━━━━━━━━━━━━━━━━━━━━━━ 
⚡ **» OS     :** `{namaos.strip().replace('"','')}`
⚡ **» CITY :** `{city.strip()}`
⚡ **» DOMAIN :** `{DOMAIN}`
⚡ **» IP VPS :** `{ipsaya.strip()}`
━━━━━━━━━━━━━━━━━━━━━━━
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)


